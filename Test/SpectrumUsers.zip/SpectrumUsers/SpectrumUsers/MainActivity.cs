﻿using Android.App;
using Android.OS;
using Android.Support.V7.App;
using Android.Runtime;
using Android.Widget;
using Android.Support.V7.Widget;
using SpectrumUsers.Adapters;
using SpectrumUsers.Model;
using System.Collections.Generic;
using Android.Content;
using Newtonsoft.Json;

namespace SpectrumUsers
{
    [Activity(Label = "@string/app_name", Theme = "@style/AppTheme", MainLauncher = true)]
    public class MainActivity : AppCompatActivity
    {
        private RecyclerView recyclerView;
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            Xamarin.Essentials.Platform.Init(this, savedInstanceState);
            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.activity_main);
            recyclerView = FindViewById<RecyclerView>(Resource.Id.recyclerView1);
            recyclerView.SetLayoutManager(new LinearLayoutManager(this));

            Button btnAddUser = FindViewById<Button>(Resource.Id.adduserbutton);
            btnAddUser.Click += (sender, e) =>
            {
                Intent intent = new Intent(this, typeof(AddUserActivity));
                StartActivity(intent);
            };
        }
        public override void OnRequestPermissionsResult(int requestCode, string[] permissions, [GeneratedEnum] Android.Content.PM.Permission[] grantResults)
        {
            Xamarin.Essentials.Platform.OnRequestPermissionsResult(requestCode, permissions, grantResults);

            base.OnRequestPermissionsResult(requestCode, permissions, grantResults);
        }

        protected override void OnStart()
        {
            base.OnStart();

            // Update Items
            recyclerView.SetAdapter(new UserDataAdapter(GetUserData())) ;
        }

        private JavaList<User> GetUserData()
        {
            JavaList<User> userData = new JavaList<User>();
            /* userData.Add(new User() { FirstName = "RAUL", LastName = "JAI", Gender = "MALE", Password = "dydyuidhdsh" });
             userData.Add(new User() { FirstName = "RAUHL", LastName = "JAI", Gender = "MALE", Password = "dhhddd" });
             userData.Add(new User() { FirstName = "RAULI", LastName = "JAY", Gender = "FEMALE", Password = "yureiru" });
             userData.Add(new User() { FirstName = "RAULI", LastName = "JAY", Gender = "FEMALE", Password = "yureiru" });
             userData.Add(new User() { FirstName = "RAULIKA", LastName = "JAIY", Gender = "FEMALE", Password = "dhdfhj" });
             userData.Add(new User() { FirstName = "RAULIKA", LastName = "JAIY", Gender = "FEMALE", Password = "dhdfhj" });*/
            ISharedPreferences pref = Application.Context.GetSharedPreferences("UserInfo", FileCreationMode.Private);
            string json = pref.GetString("UserData", string.Empty);
            if (!string.IsNullOrEmpty(json))
            {
                userData = (JavaList<User>)JsonConvert.DeserializeObject(json,typeof(JavaList<User>));
            }
            return userData;
        }
    }
}