﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Newtonsoft.Json;
using SpectrumUsers.Model;

namespace SpectrumUsers
{
    [Activity(Label = "AddUserActivity")]
    public class AddUserActivity : Activity
    {
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.AddUserData);

            EditText fisrtName = FindViewById<EditText>(Resource.Id.firstName);
            EditText lastName = FindViewById<EditText>(Resource.Id.lastName);
            EditText gender = FindViewById<EditText>(Resource.Id.gender);
            EditText password = FindViewById<EditText>(Resource.Id.password);
            Button btnSave = FindViewById<Button>(Resource.Id.btnAddUser);

            btnSave.Click += delegate
            {
                if(ValidatePassword(password.Text.ToString().Trim()))
                {
                    User usr = new User()
                    {
                        FirstName = fisrtName.Text.ToString().Trim(),
                        LastName = lastName.Text.Trim(),
                        Gender = gender.Text.ToString().Trim(),
                        Password = password.Text.ToString().Trim()
                    };
                    JavaList<User> userData = new JavaList<User>();
                    ISharedPreferences pref = Application.Context.GetSharedPreferences("UserInfo", FileCreationMode.Private);
                    if (pref != null && pref.Contains("UserData"))
                    {
                        string json = pref.GetString("UserData", string.Empty);
                        if (string.IsNullOrEmpty(json))
                        {
                            userData.Add(usr);
                        }
                        else
                        {
                            userData = (JavaList<User>)JsonConvert.DeserializeObject(json, typeof(JavaList<User>));
                            userData.Add(usr);
                        }
                    }
                    else
                    {
                        userData.Add(usr);
                    }
                    ISharedPreferencesEditor edit = pref.Edit();
                    edit.PutString("UserData", JsonConvert.SerializeObject(userData));
                    edit.Commit();
                    Intent intent = new Intent(this, typeof(MainActivity));
                    StartActivity(intent);
                }
                else
                {
                    Android.App.AlertDialog.Builder dialog = new AlertDialog.Builder(this);
                    AlertDialog alert = dialog.Create();
                    alert.SetTitle("Password Error");
                    alert.SetMessage("1.String must consist of a mixture of letters and numerical digits only, with at least one of each.\n" + "2.String must be between 5 and 12 characters in length.\n"
                        + "3.String must not contain any sequence of characters immediately followed by the same sequence");
                    alert.SetButton("OK", (c, ev) =>
                    {
                        alert.Cancel();
                    });
                    alert.Show();
                }            
            };
        }
        
        private bool ValidatePassword(String password)
        {
            return Regex.IsMatch(password,

            @"^(?!.*(?<g>[a-z\d]+)\k<g>.*)[a-z\d]{5,12}(?<=.*[a-z].*)(?<=.*\d.*)$");
        }

        protected override void OnStop()
        {
            base.OnStop();
        }
    }
}